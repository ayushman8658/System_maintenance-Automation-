# Make sure the locale variables are set to valid values.
eval $(/usr/bin/locale-check C.UTF-8)
